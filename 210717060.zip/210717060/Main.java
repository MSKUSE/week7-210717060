public class Main {
    public static void main(String[] args) {
        Member alice = new Member(1, "Alice Brown", "alice@example.com", "member123");
        Member bob = new Member(2, "Bob White", "bob@example.com", "member456");
        Librarian green = new Librarian(3, "Mr. Green", "green@example.com", "lib789");

        System.out.println(alice);
        alice.printBorrowedBooks();
        System.out.println();

        System.out.println(bob);
        bob.printBorrowedBooks();
        System.out.println();

        System.out.println(green);
        System.out.println("Library Inventory:");
        Book book1 = new Book(1, "The Great Gatsby", "F. Scott Fitzgerald");
        Book book2 = new Book(2, "1984", "George Orwell");
        green.addBook(book1);
        green.addBook(book2);
        green.printInventory();
        System.out.println();

        System.out.println("After borrowing books:");
        alice.borrowBook(book1);
        green.removeBook(book1);
        bob.borrowBook(book2);
        green.removeBook(book2);
        System.out.println(alice);
        alice.printBorrowedBooks();
        System.out.println();
        System.out.println(bob);
        bob.printBorrowedBooks();
        System.out.println();
        System.out.println(green);
        System.out.println("Library Inventory:");
        green.printInventory();
        System.out.println();

        System.out.println("After returning a book:");
        alice.returnBook(book1);
        green.addBook(book1);
        System.out.println(alice);
        alice.printBorrowedBooks();
        System.out.println("Library Inventory:");
        green.printInventory();
    }
}